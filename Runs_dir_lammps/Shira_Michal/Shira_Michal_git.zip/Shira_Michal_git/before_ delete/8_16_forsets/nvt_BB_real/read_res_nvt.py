file = open("res_nvt.txt", 'r')
file_count = open("res_nvt_count_fourths.txt", 'w')
res_lines = file.read().split('\n')
for l in res_lines:# lines of timestep - npt, with volume
	if 'The crossover attempt' in l:
		file_count.write(l+'\n')
file.close()
file_count.close()
		
